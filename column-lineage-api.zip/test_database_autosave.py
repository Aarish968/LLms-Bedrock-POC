#!/usr/bin/env python3
"""Test database auto-save functionality."""

import sys
import os
import asyncio

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api.v1.services.lineage_service import LineageService
from api.v1.models.lineage import LineageAnalysisRequest
from api.dependencies.database import DatabaseManager

async def test_database_autosave():
    """Test database auto-save functionality."""
    print("🔍 Testing Database Auto-Save Functionality")
    print("=" * 50)
    
    try:
        lineage_service = LineageService()
        db_manager = DatabaseManager()
        
        # Create analysis request for PUBLIC schema views
        request = LineageAnalysisRequest(
            view_names=["ALL_IB"],  # Test with one specific view
            database_filter="SNOWFLAKE_LEARNING_DB",
            schema_filter="PUBLIC",
            async_processing=False,  # Synchronous for testing
            include_system_views=False,
            max_views=1
        )
        
        print(f"\n1. Starting analysis for view: {request.view_names[0]}")
        print(f"   Database: {request.database_filter}")
        print(f"   Schema: {request.schema_filter}")
        
        # Create a mock job ID
        from uuid import uuid4
        job_id = uuid4()
        user_id = "test-user"
        
        print(f"   Job ID: {job_id}")
        
        # Run the analysis (this will auto-save to both CSV and database)
        results = await lineage_service.process_lineage_analysis(
            job_id=job_id,
            request=request,
            user_id=user_id
        )
        
        print(f"\n2. Analysis completed!")
        print(f"   Results count: {len(results)}")
        
        # Check if table was created and data was inserted
        print(f"\n3. Verifying database table creation and data insertion...")
        
        table_name = "COLUMN_LINEAGE_RESULTS"
        full_table_name = f"{request.database_filter}.{request.schema_filter}.{table_name}"
        
        try:
            # Check if table exists
            check_table_query = f"""
            SELECT COUNT(*) as table_exists
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_CATALOG = '{request.database_filter}'
            AND TABLE_SCHEMA = '{request.schema_filter}'
            AND TABLE_NAME = '{table_name}'
            """
            
            table_result = db_manager.execute_query(check_table_query)
            table_exists = table_result[0][0] if table_result else 0
            
            if table_exists > 0:
                print(f"✅ Table {full_table_name} exists")
                
                # Check data count
                count_query = f"SELECT COUNT(*) as record_count FROM {full_table_name}"
                count_result = db_manager.execute_query(count_query)
                record_count = count_result[0][0] if count_result else 0
                
                print(f"✅ Found {record_count} records in the table")
                
                # Show sample records
                if record_count > 0:
                    sample_query = f"""
                    SELECT 
                        JOB_ID,
                        VIEW_NAME,
                        VIEW_COLUMN,
                        COLUMN_TYPE,
                        SOURCE_TABLE,
                        SOURCE_COLUMN,
                        EXPRESSION_TYPE
                    FROM {full_table_name}
                    WHERE JOB_ID = '{job_id}'
                    ORDER BY VIEW_COLUMN
                    LIMIT 5
                    """
                    
                    sample_results = db_manager.execute_query(sample_query)
                    
                    print(f"\n4. Sample records from database:")
                    for i, row in enumerate(sample_results):
                        print(f"   Record {i+1}:")
                        print(f"     Job ID: {row[0]}")
                        print(f"     View: {row[1]}")
                        print(f"     Column: {row[2]}")
                        print(f"     Type: {row[3]}")
                        print(f"     Source: {row[4]}.{row[5]}")
                        print(f"     Expression Type: {row[6] or 'N/A'}")
                        print()
                
            else:
                print(f"❌ Table {full_table_name} does not exist")
                
        except Exception as e:
            print(f"❌ Error checking database table: {e}")
        
        print(f"\n✅ Database auto-save test completed!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_database_autosave())