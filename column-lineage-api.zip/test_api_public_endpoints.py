#!/usr/bin/env python3
"""Test public API endpoints without authentication."""

import sys
import os
import json
import requests
import time

def test_public_api_endpoints():
    """Test public API endpoints."""
    print("🔍 Testing Public API Endpoints")
    print("=" * 50)
    
    base_url = "http://localhost:8000"
    
    try:
        # Test 1: Check if server is running
        print("\n1. Testing server connectivity...")
        try:
            response = requests.get(f"{base_url}/health", timeout=5)
            if response.status_code == 200:
                print("✅ Server is running")
                print(f"   Health check: {response.json()}")
            else:
                print(f"❌ Server returned status {response.status_code}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ Server not accessible: {e}")
            return
        
        # Test 2: List databases (public endpoint)
        print("\n2. Testing database listing (public)...")
        try:
            response = requests.get(f"{base_url}/api/v1/lineage/public/databases", timeout=10)
            if response.status_code == 200:
                databases = response.json()
                print(f"✅ Found {len(databases)} databases: {databases}")
            else:
                print(f"❌ Database listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ Database listing error: {e}")
            return
        
        # Test 3: List schemas (public endpoint)
        print("\n3. Testing schema listing (public)...")
        try:
            response = requests.get(
                f"{base_url}/api/v1/lineage/public/schemas",
                params={"database_filter": "SNOWFLAKE_LEARNING_DB"},
                timeout=10
            )
            if response.status_code == 200:
                schemas = response.json()
                print(f"✅ Found {len(schemas)} schemas: {schemas}")
            else:
                print(f"❌ Schema listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ Schema listing error: {e}")
            return
        
        # Test 4: List views (public endpoint)
        print("\n4. Testing view listing (public)...")
        try:
            response = requests.get(
                f"{base_url}/api/v1/lineage/public/views",
                params={
                    "database_filter": "SNOWFLAKE_LEARNING_DB",
                    "schema_filter": "PUBLIC",
                    "limit": 10
                },
                timeout=10
            )
            if response.status_code == 200:
                views = response.json()
                print(f"✅ Found {len(views)} views")
                for view in views:
                    print(f"   - {view['view_name']} ({view['column_count']} columns)")
            else:
                print(f"❌ View listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ View listing error: {e}")
            return
        
        # Test 5: Check saved CSV files (public endpoint)
        print("\n5. Testing saved CSV files listing (public)...")
        try:
            response = requests.get(
                f"{base_url}/api/v1/lineage/public/saved-results",
                timeout=10
            )
            
            if response.status_code == 200:
                saved_files = response.json()
                print(f"✅ Found {saved_files['total_files']} saved CSV files")
                for file_info in saved_files['files'][:3]:
                    print(f"   - {file_info['filename']} ({file_info['size_bytes']} bytes)")
            else:
                print(f"❌ Saved results listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Saved results listing error: {e}")
        
        # Test 6: Check database results (public endpoint)
        print("\n6. Testing database results listing (public)...")
        try:
            response = requests.get(
                f"{base_url}/api/v1/lineage/public/database-results/SNOWFLAKE_LEARNING_DB/PUBLIC",
                params={"limit": 5},
                timeout=10
            )
            
            if response.status_code == 200:
                db_results = response.json()
                print(f"✅ Found {db_results['total_records']} database records")
                print(f"   Table: {db_results['table_name']}")
                
                if db_results['records']:
                    print(f"\n   Sample records:")
                    for i, record in enumerate(db_results['records'][:3]):
                        print(f"     Record {i+1}:")
                        print(f"       Job ID: {record['job_id']}")
                        print(f"       View: {record['view_name']}")
                        print(f"       Column: {record['view_column']}")
                        print(f"       Source: {record['source_table']}.{record['source_column']}")
                        print(f"       Type: {record['column_type']}")
                        print(f"       Created: {record['created_at']}")
                else:
                    print("   No records found")
            else:
                print(f"❌ Database results listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Database results listing error: {e}")
        
        print(f"\n✅ Public API endpoints test completed!")
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_public_api_endpoints()