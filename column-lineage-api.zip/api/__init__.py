"""Column Lineage API - FastAPI backend for database view column lineage analysis."""

__version__ = "0.1.0"