const isDev = import.meta.env.VITE_ENV === 'development' || import.meta.env.DEV

export default isDev