#!/usr/bin/env python3
"""
Test script to run a new analysis and verify the CSV format
"""

import requests
import json
import time
import csv
from pathlib import Path

def test_new_analysis():
    """Run a new analysis and check the generated CSV"""
    
    base_url = "http://127.0.0.1:8000"
    
    print("=== Testing New Analysis with Updated CSV Format ===")
    
    # Test 1: Start analysis
    print("\n1. Starting new analysis...")
    try:
        response = requests.post(
            f"{base_url}/api/v1/lineage/analyze",
            json={
                "view_names": ["TEST_VIEW"],
                "async_processing": False  # Synchronous for testing
            },
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Analysis started successfully")
            print(f"  Job ID: {result.get('job_id')}")
            print(f"  Status: {result.get('status')}")
        else:
            print(f"✗ Analysis failed: {response.status_code}")
            print(f"  Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"✗ Analysis request failed: {e}")
        return False
    
    # Test 2: Check generated CSV files
    print("\n2. Checking generated CSV files...")
    results_dir = Path("analysis_results")
    
    if not results_dir.exists():
        print("✗ No analysis_results directory found")
        return False
    
    # Get the most recent CSV file
    csv_files = sorted(results_dir.glob("lineage_analysis_*.csv"), key=lambda x: x.stat().st_mtime, reverse=True)
    
    if not csv_files:
        print("✗ No CSV files found")
        return False
    
    latest_csv = csv_files[0]
    print(f"✓ Found latest CSV file: {latest_csv.name}")
    
    # Test 3: Check CSV format
    print("\n3. Checking CSV format...")
    try:
        with open(latest_csv, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            
        print(f"CSV Headers: {headers}")
        
        # Expected headers (without extra columns)
        expected_headers = [
            "View_Name", "View_Column", "Column_Type",
            "Source_Table", "Source_Column", "Expression_Type"
        ]
        
        if headers == expected_headers:
            print("✓ CSV format is correct - no extra columns!")
            return True
        else:
            print("✗ CSV format still has issues")
            if "Confidence_Score" in headers:
                print("  - Still contains Confidence_Score column")
            if "Metadata" in headers:
                print("  - Still contains Metadata column")
            return False
            
    except Exception as e:
        print(f"✗ Error checking CSV format: {e}")
        return False

def show_csv_content():
    """Show content of the latest CSV file"""
    print("\n=== Latest CSV File Content ===")
    
    results_dir = Path("analysis_results")
    csv_files = sorted(results_dir.glob("lineage_analysis_*.csv"), key=lambda x: x.stat().st_mtime, reverse=True)
    
    if csv_files:
        latest_csv = csv_files[0]
        print(f"File: {latest_csv.name}")
        print("Content:")
        try:
            with open(latest_csv, 'r', encoding='utf-8') as f:
                content = f.read()
                print(content)
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No CSV files found")

if __name__ == "__main__":
    print("Testing new analysis with updated CSV format...")
    print("Make sure your backend server is running on http://127.0.0.1:8000")
    
    success = test_new_analysis()
    show_csv_content()
    
    if success:
        print("\n✓ SUCCESS: CSV format has been updated!")
        print("New CSV files will only contain the 6 required columns.")
    else:
        print("\n✗ FAILED: CSV format still needs fixing.")
        print("Make sure you restarted the backend server after the changes.")