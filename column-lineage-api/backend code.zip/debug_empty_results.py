#!/usr/bin/env python3
"""
Debug why analysis returns no results
"""

import requests
import json
import time

def test_database_connectivity():
    """Test if we can connect to database and see data"""
    
    base_url = "http://127.0.0.1:8000"
    
    print("=== Testing Database Connectivity ===")
    
    # Test 1: Get available databases
    try:
        response = requests.get(f"{base_url}/api/v1/lineage/public/databases", timeout=10)
        if response.status_code == 200:
            databases = response.json()
            print(f"✅ Found {len(databases)} databases: {databases}")
        else:
            print(f"❌ Failed to get databases: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error getting databases: {e}")
        return False
    
    # Test 2: Get available schemas (using default database)
    try:
        response = requests.get(f"{base_url}/api/v1/lineage/public/schemas", timeout=10)
        if response.status_code == 200:
            schemas = response.json()
            print(f"✅ Found {len(schemas)} schemas: {schemas}")
        else:
            print(f"❌ Failed to get schemas: {response.status_code}")
            print(f"Response: {response.text}")
    except Exception as e:
        print(f"❌ Error getting schemas: {e}")
    
    # Test 3: Get available views (using defaults)
    try:
        response = requests.get(f"{base_url}/api/v1/lineage/public/views", timeout=10)
        if response.status_code == 200:
            views = response.json()
            print(f"✅ Found {len(views)} views")
            
            if views:
                print("Sample views:")
                for view in views[:3]:  # Show first 3 views
                    print(f"  - {view.get('database_name', 'N/A')}.{view.get('schema_name', 'N/A')}.{view.get('view_name', 'N/A')}")
                return True
            else:
                print("⚠ No views found in database/schema")
                return False
        else:
            print(f"❌ Failed to get views: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error getting views: {e}")
        return False

def test_analysis_with_specific_views():
    """Test analysis with specific view names"""
    
    base_url = "http://127.0.0.1:8000"
    
    print("\n=== Testing Analysis with Specific Views ===")
    
    # First, get some actual view names from the database
    try:
        response = requests.get(f"{base_url}/api/v1/lineage/public/views?limit=5", timeout=10)
        if response.status_code == 200:
            views = response.json()
            if not views:
                print("❌ No views available for testing")
                return False
            
            # Use actual view names from the database
            view_names = [view['view_name'] for view in views[:3]]
            print(f"Testing with actual views: {view_names}")
            
            # Run analysis with these specific views
            analysis_response = requests.post(
                f"{base_url}/api/v1/lineage/analyze",
                json={
                    "view_names": view_names,
                    "async_processing": True,
                    "include_system_views": False
                },
                timeout=10
            )
            
            if analysis_response.status_code == 200:
                result = analysis_response.json()
                job_id = result.get('job_id')
                print(f"✅ Analysis started with specific views, job_id: {job_id}")
                
                # Wait for completion and check results
                return monitor_job_completion(job_id)
            else:
                print(f"❌ Analysis failed: {analysis_response.status_code}")
                print(f"Response: {analysis_response.text}")
                return False
                
        else:
            print(f"❌ Could not get views for testing: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Error in specific view test: {e}")
        return False

def monitor_job_completion(job_id):
    """Monitor job completion and check results"""
    
    base_url = "http://127.0.0.1:8000"
    
    print(f"Monitoring job {job_id}...")
    
    for i in range(30):  # Wait up to 30 seconds
        try:
            response = requests.get(f"{base_url}/api/v1/lineage/status/{job_id}", timeout=10)
            if response.status_code == 200:
                status_data = response.json()
                current_status = status_data.get('status')
                results_count = status_data.get('results_count', 0)
                
                print(f"  Status: {current_status}, Results: {results_count}")
                
                if current_status == 'COMPLETED':
                    if results_count > 0:
                        print(f"✅ Analysis completed with {results_count} results!")
                        
                        # Get actual results
                        results_response = requests.get(f"{base_url}/api/v1/lineage/results/{job_id}", timeout=10)
                        if results_response.status_code == 200:
                            results_data = results_response.json()
                            print(f"Sample results:")
                            for result in results_data.get('results', [])[:2]:
                                print(f"  - {result.get('view_name')}.{result.get('view_column')} -> {result.get('source_table')}.{result.get('source_column')}")
                        
                        return True
                    else:
                        print(f"❌ Analysis completed but found 0 results")
                        return False
                        
                elif current_status == 'FAILED':
                    error_msg = status_data.get('error_message', 'Unknown error')
                    print(f"❌ Analysis failed: {error_msg}")
                    return False
                    
        except Exception as e:
            print(f"❌ Error checking status: {e}")
            
        time.sleep(1)
    
    print(f"❌ Job did not complete within 30 seconds")
    return False

def check_environment_settings():
    """Check what database/schema the API is using by default"""
    
    print("\n=== Environment Settings Check ===")
    
    # Check .env file
    try:
        with open('.env', 'r') as f:
            env_content = f.read()
            
        print("Database settings from .env:")
        for line in env_content.split('\n'):
            if 'SNOWFLAKE_DATABASE' in line or 'SNOWFLAKE_SCHEMA' in line:
                print(f"  {line}")
                
    except Exception as e:
        print(f"Could not read .env file: {e}")

def main():
    """Main diagnostic function"""
    
    print("=== Debugging Empty Analysis Results ===")
    
    # Check environment settings
    check_environment_settings()
    
    # Test database connectivity
    db_ok = test_database_connectivity()
    
    if not db_ok:
        print("\n❌ ISSUE: Cannot connect to database or no views found")
        print("SOLUTIONS:")
        print("1. Check your database connection settings in .env")
        print("2. Verify the database and schema contain views")
        print("3. Check database permissions")
        return
    
    # Test analysis with specific views
    analysis_ok = test_analysis_with_specific_views()
    
    print("\n" + "="*60)
    print("DIAGNOSIS SUMMARY:")
    print(f"Database connectivity: {'✅ OK' if db_ok else '❌ ISSUE'}")
    print(f"Analysis with real views: {'✅ OK' if analysis_ok else '❌ ISSUE'}")
    
    if db_ok and not analysis_ok:
        print("\n🔧 POSSIBLE ISSUES:")
        print("1. Views exist but have no analyzable SQL content")
        print("2. Views are system views (try include_system_views: true)")
        print("3. DDL extraction is failing for these views")
        print("4. Views have complex SQL that the parser cannot handle")
        
        print("\n🔧 SOLUTIONS TO TRY:")
        print("1. Set include_system_views: true in your request")
        print("2. Try with a single simple view first")
        print("3. Check server logs for DDL extraction errors")

if __name__ == "__main__":
    main()