#!/usr/bin/env python3
"""Test complete API flow with analysis job."""

import sys
import os
import json
import asyncio
import requests
import time

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_api_flow():
    """Test complete API flow."""
    print("🔍 Testing Complete API Flow")
    print("=" * 50)
    
    base_url = "http://localhost:8000"
    
    try:
        # Test 1: Check if server is running
        print("\n1. Testing server connectivity...")
        try:
            response = requests.get(f"{base_url}/health", timeout=5)
            if response.status_code == 200:
                print("✅ Server is running")
                print(f"   Health check: {response.json()}")
            else:
                print(f"❌ Server returned status {response.status_code}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ Server not accessible: {e}")
            print("   Please start the server with: python -m uv run uvicorn api.main:app --reload")
            return
        
        # Test 2: List databases
        print("\n2. Testing database listing...")
        try:
            response = requests.get(f"{base_url}/api/v1/lineage/public/databases", timeout=10)
            if response.status_code == 200:
                databases = response.json()
                print(f"✅ Found {len(databases)} databases: {databases}")
            else:
                print(f"❌ Database listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ Database listing error: {e}")
            return
        
        # Test 3: List schemas
        print("\n3. Testing schema listing...")
        try:
            response = requests.get(
                f"{base_url}/api/v1/lineage/public/schemas",
                params={"database_filter": "SNOWFLAKE_LEARNING_DB"},
                timeout=10
            )
            if response.status_code == 200:
                schemas = response.json()
                print(f"✅ Found {len(schemas)} schemas: {schemas}")
            else:
                print(f"❌ Schema listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ Schema listing error: {e}")
            return
        
        # Test 4: List views
        print("\n4. Testing view listing...")
        try:
            response = requests.get(
                f"{base_url}/api/v1/lineage/public/views",
                params={
                    "database_filter": "SNOWFLAKE_LEARNING_DB",
                    "schema_filter": "PUBLIC",
                    "limit": 10
                },
                timeout=10
            )
            if response.status_code == 200:
                views = response.json()
                print(f"✅ Found {len(views)} views")
                for view in views:
                    print(f"   - {view['view_name']} ({view['column_count']} columns)")
            else:
                print(f"❌ View listing failed: {response.status_code}")
                print(f"   Response: {response.text}")
                return
        except requests.exceptions.RequestException as e:
            print(f"❌ View listing error: {e}")
            return
        
        # Test 5: Start analysis job
        print("\n5. Testing analysis job creation...")
        analysis_request = {
            "view_names": ["ALL_IB"],
            "database_filter": "SNOWFLAKE_LEARNING_DB",
            "schema_filter": "PUBLIC",
            "async_processing": False,  # Synchronous for testing
            "include_system_views": False,
            "max_views": 1
        }
        
        try:
            response = requests.post(
                f"{base_url}/api/v1/lineage/analyze",
                json=analysis_request,
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Analysis job created successfully")
                print(f"   Job ID: {result['job_id']}")
                print(f"   Status: {result['status']}")
                print(f"   Message: {result['message']}")
                
                job_id = result['job_id']
                
                # Test 6: Get job results
                print("\n6. Testing job results retrieval...")
                try:
                    response = requests.get(
                        f"{base_url}/api/v1/lineage/results/{job_id}",
                        timeout=10
                    )
                    
                    if response.status_code == 200:
                        results = response.json()
                        print(f"✅ Results retrieved successfully")
                        print(f"   Total results: {results['total_results']}")
                        print(f"   Results count: {len(results['results'])}")
                        
                        if results['results']:
                            print(f"\n   Sample results:")
                            for i, result in enumerate(results['results'][:3]):
                                print(f"     Result {i+1}:")
                                print(f"       View: {result['view_name']}")
                                print(f"       Column: {result['view_column']}")
                                print(f"       Source: {result['source_table']}.{result['source_column']}")
                                print(f"       Type: {result['column_type']}")
                                print(f"       Confidence: {result['confidence_score']}")
                        
                        # Test 7: Check saved CSV files
                        print("\n7. Testing saved results listing...")
                        try:
                            response = requests.get(
                                f"{base_url}/api/v1/lineage/public/saved-results",
                                timeout=10
                            )
                            
                            if response.status_code == 200:
                                saved_files = response.json()
                                print(f"✅ Found {saved_files['total_files']} saved CSV files")
                                for file_info in saved_files['files'][:3]:
                                    print(f"   - {file_info['filename']} ({file_info['size_bytes']} bytes)")
                            else:
                                print(f"❌ Saved results listing failed: {response.status_code}")
                        except requests.exceptions.RequestException as e:
                            print(f"❌ Saved results listing error: {e}")
                        
                    else:
                        print(f"❌ Results retrieval failed: {response.status_code}")
                        print(f"   Response: {response.text}")
                        
                except requests.exceptions.RequestException as e:
                    print(f"❌ Results retrieval error: {e}")
                
            else:
                print(f"❌ Analysis job creation failed: {response.status_code}")
                print(f"   Response: {response.text}")
                
        except requests.exceptions.RequestException as e:
            print(f"❌ Analysis job creation error: {e}")
        
        print(f"\n✅ API flow test completed!")
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_api_flow()