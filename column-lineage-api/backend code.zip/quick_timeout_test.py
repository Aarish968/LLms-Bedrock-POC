#!/usr/bin/env python3
"""
Quick test to identify timeout issue
"""

import requests
import json
import time

def test_connectivity():
    """Test basic connectivity"""
    base_url = "http://127.0.0.1:8000"
    
    print("=== Testing Basic Connectivity ===")
    
    try:
        # Test root endpoint
        response = requests.get(f"{base_url}/", timeout=5)
        print(f"✅ Root endpoint: {response.status_code}")
        
        # Test health endpoint
        response = requests.get(f"{base_url}/health", timeout=5)
        print(f"✅ Health endpoint: {response.status_code}")
        
        return True
    except Exception as e:
        print(f"❌ Connectivity failed: {e}")
        return False

def test_async_analysis():
    """Test async analysis (should not timeout)"""
    base_url = "http://127.0.0.1:8000"
    
    print("\n=== Testing Async Analysis ===")
    
    try:
        # Start async analysis
        response = requests.post(
            f"{base_url}/api/v1/lineage/analyze",
            json={
                "async_processing": True,  # Key: This prevents timeout
                "max_views": 5  # Limit for faster testing
            },
            timeout=10  # Short timeout since response should be immediate
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Analysis started successfully")
            print(f"Job ID: {result.get('job_id')}")
            print(f"Status: {result.get('status')}")
            return True, result.get('job_id')
        else:
            print(f"❌ Analysis failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False, None
            
    except requests.exceptions.Timeout:
        print("❌ Even async analysis timed out - server issue!")
        return False, None
    except Exception as e:
        print(f"❌ Error: {e}")
        return False, None

def test_sync_analysis():
    """Test sync analysis (might timeout)"""
    base_url = "http://127.0.0.1:8000"
    
    print("\n=== Testing Sync Analysis ===")
    
    try:
        response = requests.post(
            f"{base_url}/api/v1/lineage/analyze",
            json={
                "async_processing": False,  # This might timeout
                "max_views": 3  # Very limited for testing
            },
            timeout=30  # 30 second timeout
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Sync analysis completed")
            print(f"Job ID: {result.get('job_id')}")
            return True
        else:
            print(f"❌ Sync analysis failed: {response.status_code}")
            return False
            
    except requests.exceptions.Timeout:
        print("❌ Sync analysis timed out (expected)")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    """Main test"""
    print("=== Quick Timeout Diagnosis ===")
    
    # Test connectivity
    if not test_connectivity():
        print("\n❌ ISSUE: Basic connectivity failed")
        print("Make sure your server is running on http://127.0.0.1:8000")
        return
    
    # Test async analysis
    async_success, job_id = test_async_analysis()
    
    # Test sync analysis
    sync_success = test_sync_analysis()
    
    print("\n" + "="*50)
    print("DIAGNOSIS:")
    
    if async_success and not sync_success:
        print("✅ SOLUTION FOUND: Use async processing!")
        print("Your frontend should use:")
        print("  async_processing: true")
        print("Then poll for completion using the job_id")
        
    elif not async_success:
        print("❌ SERIOUS ISSUE: Even async requests are failing")
        print("Check server logs for errors")
        
    else:
        print("✅ Both async and sync work")
        print("The timeout might be a frontend configuration issue")
    
    print("\n" + "="*50)
    print("FRONTEND FIX:")
    print("Change your frontend request to:")
    print("""
fetch('/api/v1/lineage/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        async_processing: true,  // This is the key!
        view_names: ['YOUR_VIEWS']
    })
})
.then(response => response.json())
.then(data => {
    console.log('Analysis started:', data.job_id);
    // Now poll for completion...
});
    """)

if __name__ == "__main__":
    main()