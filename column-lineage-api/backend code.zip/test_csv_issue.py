#!/usr/bin/env python3
"""
Simple test to check CSV creation issue
"""

import requests
import json
import time
from pathlib import Path

def test_analysis_and_csv():
    """Test analysis and check CSV creation"""
    
    base_url = "http://127.0.0.1:8000"
    
    print("=== Testing Analysis and CSV Creation ===")
    
    # Check results directory
    results_dir = Path("analysis_results")
    print(f"Results directory exists: {results_dir.exists()}")
    
    if results_dir.exists():
        # Count existing CSV files
        existing_files = list(results_dir.glob("lineage_analysis_*.csv"))
        print(f"Existing CSV files: {len(existing_files)}")
        
        # Show the most recent file if any
        if existing_files:
            latest = max(existing_files, key=lambda x: x.stat().st_mtime)
            print(f"Most recent file: {latest.name} ({latest.stat().st_size} bytes)")
    else:
        print("Results directory does not exist")
        existing_files = []
    
    # Start analysis
    print("\nStarting analysis...")
    try:
        response = requests.post(
            f"{base_url}/api/v1/lineage/analyze",
            json={
                "view_names": ["TEST_VIEW"],
                "async_processing": False,
                "include_system_views": False
            },
            timeout=60
        )
        
        print(f"Response status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Analysis result: {json.dumps(result, indent=2)}")
            
            job_id = result.get('job_id')
            status = result.get('status')
            
            print(f"Job ID: {job_id}")
            print(f"Status: {status}")
            
            # Wait a moment for file creation
            print("\nWaiting for CSV file creation...")
            time.sleep(3)
            
            # Check for new files
            if results_dir.exists():
                new_files = list(results_dir.glob("lineage_analysis_*.csv"))
                print(f"CSV files after analysis: {len(new_files)}")
                
                if len(new_files) > len(existing_files):
                    print("✅ New CSV file created!")
                    
                    # Find the newest file
                    newest = max(new_files, key=lambda x: x.stat().st_mtime)
                    print(f"Newest file: {newest.name}")
                    print(f"File size: {newest.stat().st_size} bytes")
                    
                    # Show content
                    try:
                        with open(newest, 'r', encoding='utf-8') as f:
                            content = f.read()
                            print(f"File content:\n{content}")
                    except Exception as e:
                        print(f"Error reading file: {e}")
                        
                else:
                    print("❌ No new CSV file was created")
                    
                    # Check if there are any files at all
                    if new_files:
                        print("But existing files are:")
                        for f in new_files[-3:]:
                            print(f"  - {f.name} ({f.stat().st_size} bytes)")
            else:
                print("❌ Results directory still doesn't exist")
                
        else:
            print(f"❌ Analysis failed with status {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Error during analysis: {e}")

def check_server_logs():
    """Suggest checking server logs"""
    print("\n=== Server Log Check ===")
    print("Check your server terminal for any error messages related to:")
    print("- 'Auto-saving results to CSV'")
    print("- 'Failed to auto-save results to CSV'")
    print("- File permission errors")
    print("- Directory creation errors")

if __name__ == "__main__":
    test_analysis_and_csv()
    check_server_logs()
    
    print("\n" + "="*50)
    print("TROUBLESHOOTING STEPS:")
    print("1. Check if analysis_results directory exists")
    print("2. Check server logs for auto-save errors")
    print("3. Verify AUTO_SAVE_RESULTS=true in .env")
    print("4. Check file permissions on analysis_results directory")
    print("5. Run: python debug_csv_creation.py for detailed diagnosis")