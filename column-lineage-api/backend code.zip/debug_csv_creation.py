#!/usr/bin/env python3
"""
Debug script to check why CSV files are not being created
"""

import sys
import os
import requests
import json
import time
from pathlib import Path

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

def check_auto_save_settings():
    """Check if auto-save is enabled in settings"""
    try:
        from api.core.config import get_settings
        
        settings = get_settings()
        
        print("=== Auto-Save Settings ===")
        print(f"AUTO_SAVE_RESULTS: {settings.AUTO_SAVE_RESULTS}")
        print(f"RESULTS_DIRECTORY: {settings.RESULTS_DIRECTORY}")
        
        # Check if results directory exists
        results_dir = Path(settings.RESULTS_DIRECTORY)
        print(f"Results directory exists: {results_dir.exists()}")
        print(f"Results directory path: {results_dir.absolute()}")
        
        if results_dir.exists():
            # List existing files
            csv_files = list(results_dir.glob("lineage_analysis_*.csv"))
            print(f"Existing CSV files: {len(csv_files)}")
            for csv_file in csv_files[-3:]:  # Show last 3 files
                print(f"  - {csv_file.name} ({csv_file.stat().st_size} bytes)")
        
        return settings.AUTO_SAVE_RESULTS
        
    except Exception as e:
        print(f"Error checking settings: {e}")
        return False

def test_csv_generation_directly():
    """Test CSV generation directly without API"""
    try:
        from api.v1.services.lineage_service import LineageService
        from api.v1.models.lineage import ColumnLineageResult, ColumnType, ExpressionType
        from uuid import uuid4
        
        print("\n=== Direct CSV Generation Test ===")
        
        # Create sample results
        sample_results = [
            ColumnLineageResult(
                view_name="TEST_VIEW_1",
                view_column="TEST_COLUMN_1",
                column_type=ColumnType.DIRECT,
                source_table="TEST_TABLE_1",
                source_column="SOURCE_COLUMN_1",
                expression_type=ExpressionType.SUM,
                confidence_score=0.95,
                metadata={"test": "data1"}
            ),
            ColumnLineageResult(
                view_name="TEST_VIEW_2",
                view_column="TEST_COLUMN_2",
                column_type=ColumnType.DERIVED,
                source_table="TEST_TABLE_2",
                source_column="SOURCE_COLUMN_2",
                expression_type=None,
                confidence_score=0.8,
                metadata={"test": "data2"}
            )
        ]
        
        print(f"Created {len(sample_results)} sample results")
        
        # Create service and test auto-save
        service = LineageService()
        job_id = uuid4()
        
        print(f"Testing auto-save with job_id: {job_id}")
        
        # Call the auto-save method directly
        await service._auto_save_results_to_csv(job_id, sample_results)
        
        print("Auto-save method completed")
        
        # Check if file was created
        from api.core.config import get_settings
        settings = get_settings()
        results_dir = Path(settings.RESULTS_DIRECTORY)
        
        # Look for the file we just created
        csv_files = sorted(results_dir.glob("lineage_analysis_*.csv"), key=lambda x: x.stat().st_mtime, reverse=True)
        
        if csv_files:
            latest_file = csv_files[0]
            print(f"✅ CSV file created: {latest_file.name}")
            print(f"   Size: {latest_file.stat().st_size} bytes")
            
            # Read and show content
            with open(latest_file, 'r', encoding='utf-8') as f:
                content = f.read()
                print(f"   Content preview:\n{content[:200]}...")
                
            return True
        else:
            print("❌ No CSV file was created")
            return False
            
    except Exception as e:
        print(f"❌ Error in direct test: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_api_analysis():
    """Test analysis via API and check if CSV is created"""
    try:
        print("\n=== API Analysis Test ===")
        
        base_url = "http://127.0.0.1:8000"
        
        # Get current CSV file count
        from api.core.config import get_settings
        settings = get_settings()
        results_dir = Path(settings.RESULTS_DIRECTORY)
        
        before_count = len(list(results_dir.glob("lineage_analysis_*.csv"))) if results_dir.exists() else 0
        print(f"CSV files before analysis: {before_count}")
        
        # Start analysis
        print("Starting API analysis...")
        response = requests.post(
            f"{base_url}/api/v1/lineage/analyze",
            json={
                "view_names": ["TEST_VIEW"],
                "async_processing": False
            },
            timeout=60
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Analysis completed")
            print(f"   Job ID: {result.get('job_id')}")
            print(f"   Status: {result.get('status')}")
            
            # Wait a moment for file creation
            time.sleep(2)
            
            # Check CSV file count after
            after_count = len(list(results_dir.glob("lineage_analysis_*.csv"))) if results_dir.exists() else 0
            print(f"CSV files after analysis: {after_count}")
            
            if after_count > before_count:
                print("✅ New CSV file was created!")
                
                # Show the latest file
                csv_files = sorted(results_dir.glob("lineage_analysis_*.csv"), key=lambda x: x.stat().st_mtime, reverse=True)
                if csv_files:
                    latest_file = csv_files[0]
                    print(f"   Latest file: {latest_file.name}")
                    print(f"   Size: {latest_file.stat().st_size} bytes")
                    
                    # Show content
                    with open(latest_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        print(f"   Content:\n{content}")
                
                return True
            else:
                print("❌ No new CSV file was created")
                return False
                
        else:
            print(f"❌ Analysis failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Error in API test: {e}")
        return False

async def main():
    """Main diagnostic function"""
    print("=== CSV Creation Diagnostic ===")
    
    # Check settings
    auto_save_enabled = check_auto_save_settings()
    
    if not auto_save_enabled:
        print("\n❌ AUTO_SAVE_RESULTS is disabled!")
        print("To enable CSV creation, set AUTO_SAVE_RESULTS=true in your .env file")
        return
    
    # Test direct CSV generation
    direct_success = await test_csv_generation_directly()
    
    # Test API analysis
    api_success = test_api_analysis()
    
    print("\n" + "="*50)
    print("DIAGNOSTIC RESULTS:")
    print(f"Auto-save enabled: {auto_save_enabled}")
    print(f"Direct CSV generation: {'✅ SUCCESS' if direct_success else '❌ FAILED'}")
    print(f"API analysis CSV creation: {'✅ SUCCESS' if api_success else '❌ FAILED'}")
    
    if not direct_success:
        print("\n🔧 ISSUE: Direct CSV generation failed")
        print("Check server logs for errors in _auto_save_results_to_csv method")
    elif not api_success:
        print("\n🔧 ISSUE: API analysis not creating CSV")
        print("The auto-save method might not be called during API analysis")
    else:
        print("\n🎉 CSV creation is working correctly!")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())