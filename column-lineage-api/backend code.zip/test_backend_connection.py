#!/usr/bin/env python3
"""
Test script to verify backend connectivity and CORS configuration
"""

import requests
import json
import sys

def test_backend_connection():
    """Test various backend endpoints to verify connectivity"""
    
    # Different URLs to test
    base_urls = [
        "http://localhost:8000",
        "http://127.0.0.1:8000"
    ]
    
    print("=== Testing Backend Connection ===")
    
    for base_url in base_urls:
        print(f"\nTesting: {base_url}")
        
        # Test 1: Root endpoint
        try:
            response = requests.get(f"{base_url}/", timeout=5)
            print(f"✓ Root endpoint: {response.status_code}")
            if response.status_code == 200:
                print(f"  Response: {response.json()}")
        except Exception as e:
            print(f"✗ Root endpoint failed: {e}")
            continue
        
        # Test 2: Health check
        try:
            response = requests.get(f"{base_url}/health", timeout=5)
            print(f"✓ Health endpoint: {response.status_code}")
        except Exception as e:
            print(f"✗ Health endpoint failed: {e}")
        
        # Test 3: API docs
        try:
            response = requests.get(f"{base_url}/docs", timeout=5)
            print(f"✓ Docs endpoint: {response.status_code}")
        except Exception as e:
            print(f"✗ Docs endpoint failed: {e}")
        
        # Test 4: CORS preflight (OPTIONS request)
        try:
            headers = {
                'Origin': 'http://localhost:3000',
                'Access-Control-Request-Method': 'POST',
                'Access-Control-Request-Headers': 'Content-Type'
            }
            response = requests.options(f"{base_url}/api/v1/lineage/analyze", headers=headers, timeout=5)
            print(f"✓ CORS preflight: {response.status_code}")
            print(f"  CORS headers: {dict(response.headers)}")
        except Exception as e:
            print(f"✗ CORS preflight failed: {e}")
        
        # Test 5: Actual API endpoint (empty request)
        try:
            headers = {
                'Content-Type': 'application/json',
                'Origin': 'http://localhost:3000'
            }
            response = requests.post(
                f"{base_url}/api/v1/lineage/analyze", 
                json={}, 
                headers=headers, 
                timeout=10
            )
            print(f"✓ API endpoint: {response.status_code}")
            if response.status_code in [200, 422]:  # 422 is validation error, but means endpoint is reachable
                print(f"  Response: {response.text[:200]}...")
            else:
                print(f"  Error response: {response.text}")
        except Exception as e:
            print(f"✗ API endpoint failed: {e}")

def test_frontend_urls():
    """Show common frontend URLs that should work"""
    print("\n=== Frontend Configuration ===")
    print("Your backend is running on: http://127.0.0.1:8000")
    print("\nIn your frontend, use one of these URLs:")
    print("- http://localhost:8000")
    print("- http://127.0.0.1:8000")
    print("\nAPI endpoints:")
    print("- POST http://127.0.0.1:8000/api/v1/lineage/analyze")
    print("- GET  http://127.0.0.1:8000/api/v1/lineage/public/views")
    print("- GET  http://127.0.0.1:8000/docs (API documentation)")

def show_curl_examples():
    """Show curl examples for testing"""
    print("\n=== CURL Test Examples ===")
    
    examples = [
        {
            "name": "Test root endpoint",
            "cmd": "curl -X GET http://127.0.0.1:8000/"
        },
        {
            "name": "Test health endpoint", 
            "cmd": "curl -X GET http://127.0.0.1:8000/health"
        },
        {
            "name": "Test CORS with origin header",
            "cmd": "curl -X POST http://127.0.0.1:8000/api/v1/lineage/analyze -H 'Content-Type: application/json' -H 'Origin: http://localhost:3000' -d '{}'"
        },
        {
            "name": "Test analysis endpoint (empty request)",
            "cmd": "curl -X POST http://127.0.0.1:8000/api/v1/lineage/analyze -H 'Content-Type: application/json' -d '{}'"
        }
    ]
    
    for example in examples:
        print(f"\n{example['name']}:")
        print(f"{example['cmd']}")

if __name__ == "__main__":
    test_backend_connection()
    test_frontend_urls()
    show_curl_examples()
    
    print("\n" + "="*60)
    print("TROUBLESHOOTING TIPS:")
    print("1. Make sure your backend server is running")
    print("2. Check that your frontend is using the correct backend URL")
    print("3. Verify CORS origins include your frontend URL")
    print("4. Check browser developer tools for CORS errors")
    print("5. Try the curl examples above to test connectivity")
    print("="*60)