#!/usr/bin/env python3
"""Test DDL parsing for a specific view."""

import sys
import os
import json

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api.dependencies.database import DatabaseManager
from api.v1.services.sql_parser import SQLParser

def test_ddl_parsing():
    """Test DDL parsing for a specific view."""
    print("🔍 Testing DDL Parsing")
    print("=" * 50)
    
    try:
        db_manager = DatabaseManager()
        sql_parser = SQLParser()
        
        # Get DDL for ALL_IB view
        print("\n1. Getting DDL for ALL_IB view...")
        ddl_query = "SELECT GET_DDL('VIEW', 'SNOWFLAKE_LEARNING_DB.PUBLIC.ALL_IB') as ddl"
        result = db_manager.execute_query(ddl_query)
        
        if not result or len(result) == 0:
            print("❌ No DDL found")
            return
        
        ddl = getattr(result[0], 'ddl', result[0][0] if len(result[0]) > 0 else None)
        if not ddl:
            print("❌ DDL is empty")
            return
        
        print(f"✅ DDL retrieved successfully ({len(ddl)} characters)")
        print(f"\nDDL Content:")
        print("-" * 80)
        print(ddl)
        print("-" * 80)
        
        # Parse the DDL
        print(f"\n2. Parsing DDL...")
        analysis = sql_parser.analyze_ddl_statement(ddl)
        
        print(f"✅ DDL parsed successfully")
        print(f"\nParsing Results:")
        print("-" * 80)
        print(json.dumps(analysis, indent=2, default=str))
        print("-" * 80)
        
        # Check for errors
        if "error" in analysis:
            print(f"❌ Parsing error: {analysis['error']}")
        else:
            print(f"✅ No parsing errors")
            
            # Show column mappings
            column_mappings = analysis.get("column_mappings", {})
            derived_columns = analysis.get("derived_columns", {})
            
            print(f"\n3. Analysis Summary:")
            print(f"   Column mappings: {len(column_mappings)}")
            print(f"   Derived columns: {len(derived_columns)}")
            
            if column_mappings:
                print(f"\n   Column Mappings:")
                for col, mapping in column_mappings.items():
                    print(f"     {col} -> {mapping}")
            
            if derived_columns:
                print(f"\n   Derived Columns:")
                for col, derived in derived_columns.items():
                    print(f"     {col} -> {derived}")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_ddl_parsing()