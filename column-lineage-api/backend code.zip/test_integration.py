#!/usr/bin/env python3
"""
Quick integration test to verify the standalone module integration
"""

import sys
import os

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'api'))

def test_imports():
    """Test that all imports work correctly"""
    try:
        # Test standalone module imports
        from api.core.analysis import process_all_views, save_results_to_csv, CompleteIntegratedParser
        print("✓ Standalone analysis module imports successful")
        
        # Test lineage service import
        from api.v1.services.lineage_service import LineageService
        print("✓ LineageService import successful")
        
        # Test that LineageService can be instantiated
        service = LineageService()
        print("✓ LineageService instantiation successful")
        
        # Test conversion method exists
        if hasattr(service, '_convert_csv_rows_to_api_results'):
            print("✓ CSV conversion method exists")
        else:
            print("✗ CSV conversion method missing")
            
        return True
        
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        return False

def test_standalone_module():
    """Test that the standalone module components work"""
    try:
        from api.core.analysis import CompleteIntegratedParser
        
        # Test parser instantiation
        parser = CompleteIntegratedParser()
        print("✓ CompleteIntegratedParser instantiation successful")
        
        # Test basic analysis (with mock DDL)
        mock_ddl = "CREATE VIEW test_view AS SELECT col1, col2 FROM test_table"
        analysis = parser.analyze_ddl_statement(mock_ddl)
        
        if 'error' not in analysis:
            print("✓ Basic DDL analysis successful")
        else:
            print(f"✗ DDL analysis failed: {analysis['error']}")
            
        return True
        
    except Exception as e:
        print(f"✗ Standalone module test failed: {e}")
        return False

if __name__ == "__main__":
    print("=== Integration Test ===")
    
    success = True
    success &= test_imports()
    success &= test_standalone_module()
    
    if success:
        print("\n✓ All integration tests passed!")
        print("The standalone analysis module has been successfully integrated into the FastAPI backend.")
    else:
        print("\n✗ Some integration tests failed!")
        sys.exit(1)