#!/usr/bin/env python3
"""
Test script to verify CSV format has the correct columns (without Confidence_Score and Metadata)
"""

import sys
import os
import csv
import io
from pathlib import Path

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

def test_csv_export_format():
    """Test that CSV export has the correct columns"""
    try:
        from api.v1.services.lineage_service import LineageService
        from api.v1.models.lineage import ColumnLineageResult, ColumnType, ExpressionType
        
        print("=== Testing CSV Export Format ===")
        
        # Create a sample result
        sample_result = ColumnLineageResult(
            view_name="TEST_VIEW",
            view_column="TEST_COLUMN",
            column_type=ColumnType.DIRECT,
            source_table="TEST_TABLE",
            source_column="SOURCE_COLUMN",
            expression_type=ExpressionType.SUM,
            confidence_score=0.95,
            metadata={"test": "data"}
        )
        
        # Create lineage service
        service = LineageService()
        
        # Test CSV export
        csv_content = await service._export_csv([sample_result], include_metadata=True)
        csv_text = csv_content.decode('utf-8')
        
        print("Generated CSV content:")
        print(csv_text)
        
        # Parse CSV to check columns
        csv_reader = csv.reader(io.StringIO(csv_text))
        headers = next(csv_reader)
        
        print(f"\nCSV Headers: {headers}")
        
        # Expected headers (without Confidence_Score and Metadata)
        expected_headers = [
            "View_Name", "View_Column", "Column_Type",
            "Source_Table", "Source_Column", "Expression_Type"
        ]
        
        print(f"Expected Headers: {expected_headers}")
        
        # Check if headers match
        if headers == expected_headers:
            print("✓ CSV headers are correct - no extra columns!")
            return True
        else:
            print("✗ CSV headers don't match expected format")
            print(f"  Extra columns: {set(headers) - set(expected_headers)}")
            print(f"  Missing columns: {set(expected_headers) - set(headers)}")
            return False
            
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False

def check_existing_csv_files():
    """Check existing CSV files in analysis_results directory"""
    print("\n=== Checking Existing CSV Files ===")
    
    results_dir = Path("analysis_results")
    if not results_dir.exists():
        print("No analysis_results directory found")
        return
    
    csv_files = list(results_dir.glob("lineage_analysis_*.csv"))
    if not csv_files:
        print("No CSV files found in analysis_results directory")
        return
    
    print(f"Found {len(csv_files)} CSV files:")
    
    for csv_file in csv_files:
        print(f"\nChecking: {csv_file.name}")
        try:
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                headers = next(reader)
                print(f"  Headers: {headers}")
                
                # Check if it has the old format with extra columns
                if "Confidence_Score" in headers or "Metadata" in headers:
                    print("  ⚠ This file has the old format with extra columns")
                else:
                    print("  ✓ This file has the correct format")
                    
        except Exception as e:
            print(f"  ✗ Error reading file: {e}")

async def main():
    """Main test function"""
    print("Testing CSV format after removing Confidence_Score and Metadata columns...")
    
    success = await test_csv_export_format()
    check_existing_csv_files()
    
    if success:
        print("\n✓ CSV format test passed!")
        print("New CSV files will only have these columns:")
        print("- View_Name")
        print("- View_Column") 
        print("- Column_Type")
        print("- Source_Table")
        print("- Source_Column")
        print("- Expression_Type")
        print("\nConfidence_Score and Metadata columns have been removed.")
    else:
        print("\n✗ CSV format test failed!")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())