#!/usr/bin/env python3
"""
Test CSV creation directly with sample data
"""

import sys
import os
import asyncio
from uuid import uuid4

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

async def test_csv_creation_with_sample_data():
    """Test CSV creation with sample data to verify the mechanism works"""
    
    try:
        from api.v1.services.lineage_service import LineageService
        from api.v1.models.lineage import ColumnLineageResult, ColumnType, ExpressionType
        
        print("=== Testing CSV Creation with Sample Data ===")
        
        # Create sample results (simulating what a real analysis would produce)
        sample_results = [
            ColumnLineageResult(
                view_name="CUSTOMER_VIEW",
                view_column="CUSTOMER_ID",
                column_type=ColumnType.DIRECT,
                source_table="CUSTOMERS",
                source_column="ID",
                expression_type=None,
                confidence_score=1.0,
                metadata={"analysis_method": "test"}
            ),
            ColumnLineageResult(
                view_name="CUSTOMER_VIEW", 
                view_column="FULL_NAME",
                column_type=ColumnType.DERIVED,
                source_table="CUSTOMERS",
                source_column="FIRST_NAME",
                expression_type=ExpressionType.CONCAT,
                confidence_score=0.9,
                metadata={"analysis_method": "test"}
            ),
            ColumnLineageResult(
                view_name="ORDER_SUMMARY",
                view_column="TOTAL_AMOUNT",
                column_type=ColumnType.DERIVED,
                source_table="ORDERS",
                source_column="AMOUNT",
                expression_type=ExpressionType.SUM,
                confidence_score=0.95,
                metadata={"analysis_method": "test"}
            )
        ]
        
        print(f"Created {len(sample_results)} sample results")
        
        # Create lineage service
        service = LineageService()
        job_id = uuid4()
        
        print(f"Testing CSV auto-save with job_id: {job_id}")
        
        # Test the auto-save method directly
        await service._auto_save_results_to_csv(job_id, sample_results)
        
        # Check if file was created
        from pathlib import Path
        from api.core.config import get_settings
        
        settings = get_settings()
        results_dir = Path(settings.RESULTS_DIRECTORY)
        
        # Look for the file we just created
        csv_files = sorted(results_dir.glob("lineage_analysis_*.csv"), key=lambda x: x.stat().st_mtime, reverse=True)
        
        if csv_files:
            latest_file = csv_files[0]
            print(f"✅ CSV file created: {latest_file.name}")
            print(f"   Size: {latest_file.stat().st_size} bytes")
            
            # Read and display content
            with open(latest_file, 'r', encoding='utf-8') as f:
                content = f.read()
                print(f"   Content:\n{content}")
            
            # Verify the content has the correct format
            lines = content.strip().split('\n')
            headers = lines[0].split(',')
            
            expected_headers = ["View_Name", "View_Column", "Column_Type", "Source_Table", "Source_Column", "Expression_Type"]
            
            if headers == expected_headers:
                print("✅ CSV headers are correct!")
                print("✅ CSV creation mechanism is working!")
                return True
            else:
                print(f"❌ CSV headers are wrong: {headers}")
                return False
                
        else:
            print("❌ No CSV file was created")
            return False
            
    except Exception as e:
        print(f"❌ Error testing CSV creation: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_empty_results_handling():
    """Test what happens when we try to save empty results"""
    
    try:
        from api.v1.services.lineage_service import LineageService
        
        print("\n=== Testing Empty Results Handling ===")
        
        service = LineageService()
        job_id = uuid4()
        
        print("Testing auto-save with empty results list...")
        
        # Test with empty results (this is what's happening in your case)
        await service._auto_save_results_to_csv(job_id, [])
        
        print("✅ Empty results handled correctly (no CSV should be created)")
        return True
        
    except Exception as e:
        print(f"❌ Error testing empty results: {e}")
        return False

def main():
    """Main test function"""
    
    print("=== Direct CSV Creation Test ===")
    
    async def run_tests():
        # Test CSV creation with sample data
        csv_works = await test_csv_creation_with_sample_data()
        
        # Test empty results handling
        empty_works = await test_empty_results_handling()
        
        print("\n" + "="*50)
        print("TEST RESULTS:")
        print(f"CSV creation with data: {'✅ WORKS' if csv_works else '❌ BROKEN'}")
        print(f"Empty results handling: {'✅ WORKS' if empty_works else '❌ BROKEN'}")
        
        if csv_works:
            print("\n🎉 CSV CREATION MECHANISM IS WORKING!")
            print("The issue is that your analysis returns no results.")
            print("\nNext steps:")
            print("1. Run: python debug_empty_results.py")
            print("2. Check why your database analysis finds no views/data")
            print("3. Verify your database connection and view permissions")
        else:
            print("\n❌ CSV CREATION MECHANISM IS BROKEN!")
            print("There's an issue with the CSV auto-save method itself.")
    
    asyncio.run(run_tests())

if __name__ == "__main__":
    main()