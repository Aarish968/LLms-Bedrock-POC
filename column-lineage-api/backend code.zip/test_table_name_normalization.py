#!/usr/bin/env python3
"""
Test script to verify table name normalization functionality
"""

import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.v1.services.lineage_service import LineageService

def test_table_name_normalization():
    """Test the table name normalization functionality"""
    
    print("=== Testing Table Name Normalization ===")
    
    # Create service instance
    service = LineageService()
    
    # Test cases
    test_cases = [
        {
            "input": "SNOWFLAKE_LEARNING_DB.PUBLIC.ALL_IB_NEW",
            "expected_pattern": "CPS_DB.CPS_DSCI_BR.ALL_IB_NEW"
        },
        {
            "input": "SNOWFLAKE_LEARNING_DB.PUBLIC.DC_BOOKINGS_CONTRACTS", 
            "expected_pattern": "CPS_DB.CPS_DSCI_BR.DC_BOOKINGS_CONTRACTS"
        },
        {
            "input": "PUBLIC.SOME_TABLE",
            "expected_pattern": "CPS_DB.PUBLIC.SOME_TABLE"
        },
        {
            "input": "SIMPLE_TABLE",
            "expected_pattern": "SIMPLE_TABLE"  # Should remain unchanged
        }
    ]
    
    print(f"Testing {len(test_cases)} cases...\n")
    
    for i, test_case in enumerate(test_cases, 1):
        input_table = test_case["input"]
        expected = test_case["expected_pattern"]
        
        try:
            result = service._normalize_source_table_name(input_table)
            
            print(f"Test {i}:")
            print(f"  Input:    {input_table}")
            print(f"  Expected: {expected}")
            print(f"  Result:   {result}")
            
            if result == expected:
                print(f"  Status:   ✅ PASS")
            else:
                print(f"  Status:   ❌ FAIL")
            
            print()
            
        except Exception as e:
            print(f"Test {i}: ❌ ERROR - {e}")
            print()

if __name__ == "__main__":
    test_table_name_normalization()