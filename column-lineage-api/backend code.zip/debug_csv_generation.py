#!/usr/bin/env python3
"""
Debug script to test CSV generation directly
"""

import sys
import os
import asyncio

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

async def test_csv_generation():
    """Test CSV generation directly"""
    try:
        from api.v1.services.lineage_service import LineageService
        from api.v1.models.lineage import ColumnLineageResult, ColumnType, ExpressionType
        
        print("=== Direct CSV Generation Test ===")
        
        # Create a sample result
        sample_result = ColumnLineageResult(
            view_name="TEST_VIEW",
            view_column="TEST_COLUMN", 
            column_type=ColumnType.DIRECT,
            source_table="TEST_TABLE",
            source_column="SOURCE_COLUMN",
            expression_type=ExpressionType.SUM,
            confidence_score=0.95,
            metadata={"test": "data"}
        )
        
        print("Sample result created:")
        print(f"  View: {sample_result.view_name}")
        print(f"  Column: {sample_result.view_column}")
        print(f"  Confidence: {sample_result.confidence_score}")
        print(f"  Metadata: {sample_result.metadata}")
        
        # Create lineage service
        service = LineageService()
        print("\nLineageService created")
        
        # Test CSV export with metadata=True
        print("\nTesting _export_csv with include_metadata=True...")
        csv_content_with_meta = await service._export_csv([sample_result], include_metadata=True)
        csv_text_with_meta = csv_content_with_meta.decode('utf-8')
        
        print("CSV with metadata=True:")
        print(csv_text_with_meta)
        
        # Test CSV export with metadata=False
        print("\nTesting _export_csv with include_metadata=False...")
        csv_content_without_meta = await service._export_csv([sample_result], include_metadata=False)
        csv_text_without_meta = csv_content_without_meta.decode('utf-8')
        
        print("CSV with metadata=False:")
        print(csv_text_without_meta)
        
        # Check headers
        lines_with_meta = csv_text_with_meta.strip().split('\n')
        lines_without_meta = csv_text_without_meta.strip().split('\n')
        
        headers_with_meta = lines_with_meta[0].split(',')
        headers_without_meta = lines_without_meta[0].split(',')
        
        print(f"\nHeaders with metadata=True: {headers_with_meta}")
        print(f"Headers with metadata=False: {headers_without_meta}")
        
        # Check if extra columns are present
        extra_columns = []
        if "Confidence_Score" in headers_with_meta:
            extra_columns.append("Confidence_Score")
        if "Metadata" in headers_with_meta:
            extra_columns.append("Metadata")
            
        if extra_columns:
            print(f"\n❌ PROBLEM FOUND: Extra columns still present: {extra_columns}")
            return False
        else:
            print(f"\n✅ SUCCESS: No extra columns found!")
            return True
            
    except Exception as e:
        print(f"❌ Error during test: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_method_source():
    """Check the actual source code of the _export_csv method"""
    try:
        from api.v1.services.lineage_service import LineageService
        import inspect
        
        print("\n=== Method Source Code Check ===")
        
        service = LineageService()
        method = service._export_csv
        
        # Get the source code
        source = inspect.getsource(method)
        print("Current _export_csv method source:")
        print(source)
        
        # Check if the source contains the problematic lines
        if "Confidence_Score" in source:
            print("\n❌ PROBLEM: Method source still contains 'Confidence_Score'")
            return False
        elif "Metadata" in source and "fieldnames.append" in source:
            print("\n❌ PROBLEM: Method source still contains metadata appending logic")
            return False
        else:
            print("\n✅ Method source looks correct")
            return True
            
    except Exception as e:
        print(f"❌ Error checking method source: {e}")
        return False

if __name__ == "__main__":
    print("Debugging CSV generation...")
    
    async def main():
        success1 = await test_csv_generation()
        success2 = await test_method_source()
        
        if success1 and success2:
            print("\n🎉 CSV generation is working correctly!")
            print("If you're still seeing old CSV format, try:")
            print("1. Restart your backend server completely")
            print("2. Clear any Python cache (__pycache__ folders)")
            print("3. Make sure you're testing with a new analysis request")
        else:
            print("\n❌ CSV generation still has issues!")
            print("The _export_csv method needs to be fixed.")
    
    asyncio.run(main())