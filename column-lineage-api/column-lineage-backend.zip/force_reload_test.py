#!/usr/bin/env python3
"""
Force reload modules and test CSV generation
"""

import sys
import os
import importlib
import asyncio

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

def force_reload_modules():
    """Force reload all relevant modules"""
    modules_to_reload = [
        'api.v1.services.lineage_service',
        'api.v1.models.lineage',
        'api.v1.services.job_manager'
    ]
    
    print("=== Force Reloading Modules ===")
    for module_name in modules_to_reload:
        try:
            if module_name in sys.modules:
                print(f"Reloading: {module_name}")
                importlib.reload(sys.modules[module_name])
            else:
                print(f"Importing: {module_name}")
                __import__(module_name)
        except Exception as e:
            print(f"Failed to reload {module_name}: {e}")

async def test_after_reload():
    """Test CSV generation after force reload"""
    try:
        # Force reload
        force_reload_modules()
        
        # Import after reload
        from api.v1.services.lineage_service import LineageService
        from api.v1.models.lineage import ColumnLineageResult, ColumnType, ExpressionType
        
        print("\n=== Testing After Reload ===")
        
        # Create sample result
        sample_result = ColumnLineageResult(
            view_name="TEST_VIEW",
            view_column="TEST_COLUMN",
            column_type=ColumnType.DIRECT,
            source_table="TEST_TABLE", 
            source_column="SOURCE_COLUMN",
            expression_type=ExpressionType.SUM,
            confidence_score=0.95,
            metadata={"test": "data"}
        )
        
        # Create service and test
        service = LineageService()
        csv_content = await service._export_csv([sample_result], include_metadata=True)
        csv_text = csv_content.decode('utf-8')
        
        print("Generated CSV:")
        print(csv_text)
        
        # Check headers
        lines = csv_text.strip().split('\n')
        headers = lines[0].split(',')
        
        print(f"\nHeaders: {headers}")
        
        # Expected headers
        expected = ["View_Name", "View_Column", "Column_Type", "Source_Table", "Source_Column", "Expression_Type"]
        
        if headers == expected:
            print("✅ SUCCESS: Headers are correct!")
            return True
        else:
            print("❌ FAILED: Headers are still wrong!")
            print(f"Expected: {expected}")
            print(f"Got: {headers}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    asyncio.run(test_after_reload())