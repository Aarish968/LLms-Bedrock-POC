#!/usr/bin/env python3
"""
Test script to verify that pagination parameters have been removed
"""

import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_api_signatures():
    """Test that the API signatures no longer include limit/offset parameters"""
    
    print("=== Testing API Signature Changes ===")
    
    # Test lineage service method signature
    from api.v1.services.lineage_service import LineageService
    import inspect
    
    service = LineageService()
    
    # Get the method signature
    sig = inspect.signature(service.get_available_views)
    params = list(sig.parameters.keys())
    
    print(f"LineageService.get_available_views parameters: {params}")
    
    # Check that limit and offset are not in parameters
    if 'limit' not in params and 'offset' not in params:
        print("✅ PASS: limit and offset parameters removed from LineageService.get_available_views")
    else:
        print("❌ FAIL: limit and/or offset parameters still present")
    
    # Check required parameters are still there
    required_params = ['schema_filter', 'database_filter']
    missing_params = [p for p in required_params if p not in params]
    
    if not missing_params:
        print("✅ PASS: Required parameters (schema_filter, database_filter) are present")
    else:
        print(f"❌ FAIL: Missing required parameters: {missing_params}")
    
    print("\n=== Test Complete ===")

if __name__ == "__main__":
    test_api_signatures()