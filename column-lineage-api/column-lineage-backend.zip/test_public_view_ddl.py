#!/usr/bin/env python3
"""Test DDL retrieval for PUBLIC schema views."""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api.dependencies.database import DatabaseManager

def test_public_view_ddl():
    """Test DDL retrieval for PUBLIC schema views."""
    print("🔍 Testing DDL Retrieval for PUBLIC Views")
    print("=" * 50)
    
    try:
        db_manager = DatabaseManager()
        
        # Get the list of views in PUBLIC schema
        print("\n1. Getting views in PUBLIC schema...")
        views_query = """
        SELECT TABLE_NAME
        FROM SNOWFLAKE_LEARNING_DB.INFORMATION_SCHEMA.VIEWS
        WHERE TABLE_CATALOG = 'SNOWFLAKE_LEARNING_DB'
        AND TABLE_SCHEMA = 'PUBLIC'
        ORDER BY TABLE_NAME
        """
        
        results = db_manager.execute_query(views_query)
        if not results:
            print("❌ No views found in PUBLIC schema")
            return
        
        print(f"✅ Found {len(results)} views in PUBLIC schema")
        
        # Test DDL retrieval for each view
        for row in results:
            view_name = getattr(row, 'TABLE_NAME', row[0] if len(row) > 0 else 'unknown')
            print(f"\n2. Testing DDL retrieval for view: {view_name}")
            
            # Try different DDL retrieval methods
            ddl_methods = [
                f"SELECT GET_DDL('VIEW', 'SNOWFLAKE_LEARNING_DB.PUBLIC.{view_name}') as ddl",
                f"SELECT GET_DDL('VIEW', 'PUBLIC.{view_name}') as ddl",
                f"SELECT GET_DDL('VIEW', '{view_name}') as ddl"
            ]
            
            ddl_found = False
            for method in ddl_methods:
                try:
                    print(f"   Trying: {method}")
                    result = db_manager.execute_query(method)
                    if result and len(result) > 0:
                        ddl = getattr(result[0], 'ddl', result[0][0] if len(result[0]) > 0 else None)
                        if ddl:
                            print(f"   ✅ Success! DDL length: {len(ddl)} characters")
                            print(f"   DDL preview: {ddl[:200]}...")
                            ddl_found = True
                            break
                except Exception as e:
                    print(f"   ❌ Failed: {str(e)[:100]}...")
            
            if not ddl_found:
                print(f"   ❌ All DDL methods failed for {view_name}")
            
            # Only test first view to avoid too much output
            break
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_public_view_ddl()