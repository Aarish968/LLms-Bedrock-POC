#!/usr/bin/env python3
"""
Test script to verify auto-save database configuration
"""

import os
import sys
import json
import requests
from datetime import datetime

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_configuration():
    """Test the configuration endpoint to see auto-save settings"""
    print("=== Auto-Save Configuration Test ===\n")
    
    base_url = "http://localhost:8000"  # Adjust if needed
    
    try:
        # Test config endpoint
        response = requests.get(f"{base_url}/api/v1/lineage/public/config", timeout=10)
        
        if response.status_code == 200:
            config = response.json()
            
            print("Current Auto-Save Configuration:")
            auto_save_config = config.get('auto_save_settings', {})
            
            print(f"  AUTO_SAVE_RESULTS: {auto_save_config.get('AUTO_SAVE_RESULTS')}")
            print(f"  AUTO_SAVE_TO_DATABASE: {auto_save_config.get('AUTO_SAVE_TO_DATABASE')}")
            print()
            
            print("Target Database Configuration:")
            print(f"  AUTO_SAVE_TARGET_DATABASE: {auto_save_config.get('AUTO_SAVE_TARGET_DATABASE')}")
            print(f"  AUTO_SAVE_TARGET_SCHEMA: {auto_save_config.get('AUTO_SAVE_TARGET_SCHEMA')}")
            print(f"  AUTO_SAVE_TARGET_TABLE: {auto_save_config.get('AUTO_SAVE_TARGET_TABLE')}")
            print()
            
            print("Override Configuration:")
            print(f"  AUTO_SAVE_DATABASE_OVERRIDE: {auto_save_config.get('AUTO_SAVE_DATABASE_OVERRIDE')}")
            print(f"  AUTO_SAVE_SCHEMA_OVERRIDE: {auto_save_config.get('AUTO_SAVE_SCHEMA_OVERRIDE')}")
            print()
            
            # Show where results will be saved
            target_db = auto_save_config.get('AUTO_SAVE_TARGET_DATABASE') or 'DEFAULT'
            target_schema = auto_save_config.get('AUTO_SAVE_TARGET_SCHEMA') or 'DEFAULT'
            target_table = auto_save_config.get('AUTO_SAVE_TARGET_TABLE') or 'VIEW_TO_SOURCE_COLUMN_LINEAGE'
            
            print(f"Results will be saved to: {target_db}.{target_schema}.{target_table}")
            
        else:
            print(f"Failed to get config: {response.status_code}")
            print(response.text)
            
    except Exception as e:
        print(f"Error testing config endpoint: {e}")

def show_environment_values():
    """Show current environment variable values for auto-save"""
    print("\n=== Environment Variables for Auto-Save ===\n")
    
    env_vars = [
        "AUTO_SAVE_RESULTS",
        "AUTO_SAVE_TO_DATABASE",
        "AUTO_SAVE_TARGET_DATABASE",
        "AUTO_SAVE_TARGET_SCHEMA", 
        "AUTO_SAVE_TARGET_TABLE",
        "AUTO_SAVE_DATABASE_OVERRIDE",
        "AUTO_SAVE_SCHEMA_OVERRIDE",
    ]
    
    for var in env_vars:
        value = os.getenv(var, "Not Set")
        print(f"{var}: {value}")

def show_configuration_examples():
    """Show configuration examples"""
    print("\n=== Configuration Examples ===\n")
    
    examples = [
        {
            "name": "Save to Same Database/Schema as Source",
            "config": {
                "AUTO_SAVE_TO_DATABASE": "true",
                "# AUTO_SAVE_TARGET_DATABASE": "# Not set - uses source database",
                "# AUTO_SAVE_TARGET_SCHEMA": "# Not set - uses source schema"
            }
        },
        {
            "name": "Save to Different Database/Schema",
            "config": {
                "AUTO_SAVE_TO_DATABASE": "true",
                "AUTO_SAVE_TARGET_DATABASE": "LINEAGE_DB",
                "AUTO_SAVE_TARGET_SCHEMA": "RESULTS_SCHEMA",
                "AUTO_SAVE_TARGET_TABLE": "COLUMN_LINEAGE_RESULTS"
            }
        },
        {
            "name": "Save to Centralized Results Database",
            "config": {
                "AUTO_SAVE_TO_DATABASE": "true",
                "AUTO_SAVE_TARGET_DATABASE": "ANALYTICS_DB",
                "AUTO_SAVE_TARGET_SCHEMA": "LINEAGE",
                "AUTO_SAVE_TARGET_TABLE": "ALL_COLUMN_LINEAGE"
            }
        },
        {
            "name": "Disable Database Auto-Save",
            "config": {
                "AUTO_SAVE_TO_DATABASE": "false"
            }
        }
    ]
    
    for example in examples:
        print(f"Example: {example['name']}")
        for key, value in example['config'].items():
            print(f"  {key}={value}")
        print()

def test_save_scenarios():
    """Test different save scenarios"""
    print("\n=== Save Scenarios ===\n")
    
    scenarios = [
        {
            "name": "Request with CPS_DB.CPS_DSCI_BR",
            "request_db": "CPS_DB",
            "request_schema": "CPS_DSCI_BR",
            "target_db": os.getenv('AUTO_SAVE_TARGET_DATABASE'),
            "target_schema": os.getenv('AUTO_SAVE_TARGET_SCHEMA'),
        },
        {
            "name": "Request with CUSTOM_DB.CUSTOM_SCHEMA",
            "request_db": "CUSTOM_DB", 
            "request_schema": "CUSTOM_SCHEMA",
            "target_db": os.getenv('AUTO_SAVE_TARGET_DATABASE'),
            "target_schema": os.getenv('AUTO_SAVE_TARGET_SCHEMA'),
        }
    ]
    
    for scenario in scenarios:
        print(f"Scenario: {scenario['name']}")
        print(f"  Request Database: {scenario['request_db']}")
        print(f"  Request Schema: {scenario['request_schema']}")
        
        # Determine where it will actually save
        actual_db = scenario['target_db'] or scenario['request_db']
        actual_schema = scenario['target_schema'] or scenario['request_schema']
        actual_table = os.getenv('AUTO_SAVE_TARGET_TABLE', 'VIEW_TO_SOURCE_COLUMN_LINEAGE')
        
        print(f"  Will Save To: {actual_db}.{actual_schema}.{actual_table}")
        print()

if __name__ == "__main__":
    show_environment_values()
    show_configuration_examples()
    test_save_scenarios()
    test_configuration()