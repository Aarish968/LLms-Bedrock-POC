#!/usr/bin/env python3
"""
Final test to verify that database_filter and schema_filter are no longer required
"""

import sys
import os
import json

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

def test_model_with_defaults():
    """Test that the model works with default values from environment"""
    try:
        from api.v1.models.lineage import LineageAnalysisRequest, DEFAULT_DATABASE, DEFAULT_SCHEMA
        
        print("=== Testing Model with Environment Defaults ===")
        print(f"Default Database: {DEFAULT_DATABASE}")
        print(f"Default Schema: {DEFAULT_SCHEMA}")
        
        # Test 1: Completely empty request
        print("\n1. Testing completely empty request...")
        try:
            empty_request = LineageAnalysisRequest()
            print("✓ Empty request created successfully")
            print(f"  database_filter: '{empty_request.database_filter}'")
            print(f"  schema_filter: '{empty_request.schema_filter}'")
            print(f"  view_names: {empty_request.view_names}")
        except Exception as e:
            print(f"✗ Empty request failed: {e}")
            return False
        
        # Test 2: Request from empty JSON (simulating API call)
        print("\n2. Testing request from empty JSON...")
        try:
            json_request = LineageAnalysisRequest(**{})
            print("✓ Empty JSON request created successfully")
            print(f"  database_filter: '{json_request.database_filter}'")
            print(f"  schema_filter: '{json_request.schema_filter}'")
        except Exception as e:
            print(f"✗ Empty JSON request failed: {e}")
            return False
        
        # Test 3: Request with only view_names
        print("\n3. Testing request with only view_names...")
        try:
            view_request = LineageAnalysisRequest(view_names=["TEST_VIEW"])
            print("✓ View names request created successfully")
            print(f"  view_names: {view_request.view_names}")
            print(f"  database_filter: '{view_request.database_filter}'")
            print(f"  schema_filter: '{view_request.schema_filter}'")
        except Exception as e:
            print(f"✗ View names request failed: {e}")
            return False
        
        # Test 4: Request with custom database/schema (should override defaults)
        print("\n4. Testing request with custom database/schema...")
        try:
            custom_request = LineageAnalysisRequest(
                database_filter="CUSTOM_DB",
                schema_filter="CUSTOM_SCHEMA"
            )
            print("✓ Custom request created successfully")
            print(f"  database_filter: '{custom_request.database_filter}'")
            print(f"  schema_filter: '{custom_request.schema_filter}'")
        except Exception as e:
            print(f"✗ Custom request failed: {e}")
            return False
        
        # Test 5: Serialize to JSON (what API would receive)
        print("\n5. Testing JSON serialization...")
        try:
            request = LineageAnalysisRequest()
            json_data = request.model_dump()
            print("✓ JSON serialization successful")
            print(f"  JSON: {json.dumps(json_data, indent=2)}")
        except Exception as e:
            print(f"✗ JSON serialization failed: {e}")
            return False
        
        return True
        
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        return False

def show_curl_examples():
    """Show curl examples that should now work"""
    print("\n=== CURL Examples That Should Now Work ===")
    
    examples = [
        {
            "name": "Completely empty request",
            "data": "{}"
        },
        {
            "name": "Request with only view names",
            "data": '{"view_names": ["VIEW1", "VIEW2"]}'
        },
        {
            "name": "Request with custom settings",
            "data": '{"database_filter": "MY_DB", "schema_filter": "MY_SCHEMA"}'
        },
        {
            "name": "Full request",
            "data": '{"view_names": ["VIEW1"], "include_system_views": false, "max_views": 10}'
        }
    ]
    
    for example in examples:
        print(f"\n{example['name']}:")
        print(f"curl -X POST 'http://localhost:8000/api/v1/lineage/analyze' \\")
        print(f"  -H 'Content-Type: application/json' \\")
        print(f"  -d '{example['data']}'")

if __name__ == "__main__":
    print("Testing final validation fix...")
    
    success = test_model_with_defaults()
    show_curl_examples()
    
    if success:
        print("\n" + "="*60)
        print("✓ ALL TESTS PASSED!")
        print("✓ database_filter and schema_filter are NO LONGER REQUIRED")
        print("✓ Default values are automatically used from environment")
        print("✓ API requests can now be made without these fields")
        print("="*60)
        print("\nIMPORTANT: Restart your API server to load the updated code!")
    else:
        print("\n✗ TESTS FAILED!")
        print("The model still has issues with the required fields.")
        sys.exit(1)