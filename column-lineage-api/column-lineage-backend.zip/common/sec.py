import os
import hvac
import json
from urllib.parse import quote_plus as urlquote
from sqlalchemy.dialects import registry
import socket
import boto3
import base64
from . import aws_sec


registry.register('snowflake', 'snowflake.sqlalchemy', 'dialect')


s3_client = boto3.client("s3")
ssm_client = boto3.client("ssm", "us-east-1")


def decrypt_parameter(parameter_name: str):
    parameter = ssm_client.get_parameter(Name=parameter_name, WithDecryption=True)
    return parameter["Parameter"]["Value"]


def get_prefect_token():
    PREFECT_AUTH_TOKEN = decrypt_parameter(f"/cam/dev/prefect/token")
    return PREFECT_AUTH_TOKEN






def get_secret(secret_name):


    region_name = "us-east-1"


    # Create a Secrets Manager client using default AWS CLI credentials
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )


    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )


    if 'SecretString' in get_secret_value_response:
        secret = eval(get_secret_value_response['SecretString'])
        return secret
    else:
        decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
        return decoded_binary_secret






def sf_key():
    sf_key_info = {


        'prd_cps_dsci_etl_svc':


            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('prd_cps_dsci_etl_svc')['prd_cps_dsci_etl_svc'],
                'secret': 'secret/snowflake/prd/cps_dsci_etl_svc/password',
                'snowflake_db_engine_str': get_secret("prd_cps_dsci_etl_svc_local_conn_str")["prd_cps_dsci_etl_svc_local_conn_str"],
                'cloud_snowflake_db_engine_str': get_secret('prd_cps_dsci_etl_svc_cloud_conn_str')['prd_cps_dsci_etl_svc_cloud_conn_str'],
            },


        'prd_cps_dsci_rpt_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('prd_cps_dsci_rpt_svc')['prd_cps_dsci_rpt_svc'],
                'secret': 'secret/snowflake/prd/cps_dsci_rpt_svc/password',
                'snowflake_db_engine_str': 'snowflake://cps_dsci_rpt_svc:{pw}@cisco.us-east-1/CPS_DB/{schema}?warehouse={wh}&role=cps_dsci_rpt_role'


            },


        'prd_cps_cdods_etl_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('prd_cps_cdods_etl_svc')['prd_cps_cdods_etl_svc'],
                'secret': 'secret/snowflake/prd/cps_cdods_etl_svc/password',
                'snowflake_db_engine_str': 'snowflake://cps_cdods_etl_svc:{pw}@cisco.us-east-1/CPS_DB/{schema}?warehouse={wh}&role=cps_cdods_etl_role'


            },
        'prd_cps_cdods_rpt_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('prd_cps_cdods_rpt_svc')['prd_cps_cdods_rpt_svc'],
                'secret': 'secret/snowflake/prd/cps_cdods_rpt_svc/password',
                'snowflake_db_engine_str': 'snowflake://cps_cdods_rpt_svc:{pw}@cisco.us-east-1/CPS_DB/{schema}?warehouse={wh}&role=cps_cdods_rpt_role'
            },


        'dev_cps_dsci_etl_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('dev_cps_dsci_etl_svc')['dev_cps_dsci_etl_svc'],
                'secret': 'secret/snowflake/dev/cps_dsci_etl_svc/password',
                'snowflake_db_engine_str': get_secret("dev_cps_dsci_etl_svc_local_conn_str")["dev_cps_dsci_etl_svc_local_conn_str"],
                'cloud_snowflake_db_engine_str': get_secret("dev_cps_dsci_etl_svc_cloud_conn_str")["dev_cps_dsci_etl_svc_cloud_conn_str"],


            },
        'stg_cps_dsci_etl_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('stg_cps_dsci_etl_svc')['stg_cps_dsci_etl_svc'],
                'secret': 'secret/snowflake/stg/cps_dsci_etl_svc/password',
                'snowflake_db_engine_str': 'snowflake://cps_dsci_etl_svc:{pw}@ciscostage.us-east-1.privatelink/CPS_DB/{schema}?warehouse={wh}'
            },


        'dev_cps_dsci_rpt_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('dev_cps_dsci_rpt_svc')['dev_cps_dsci_rpt_svc'],
                'secret': 'secret/snowflake/dev/cps_dsci_rpt_svc/password',
                'snowflake_db_engine_str': 'snowflake://cps_dsci_rpt_svc:{pw}@ciscodev.us-east-1/CPS_DB/{schema}?warehouse={wh}'
            },
        'dev_cps_bia_etl_svc':
            {
                'url': 'https://east.keeper.cisco.com',
                'namespace': 'cloudDB',
                'token': get_secret('dev_cps_bia_etl_svc')['dev_cps_bia_etl_svc'],
                'secret': 'secret/snowflake/dev/cps_bia_etl_svc/password',
                'snowflake_db_engine_str': 'snowflake://cps_bia_etl_svc:{pw}@ciscodev.us-east-1/CPS_DB/{schema}?warehouse={wh}&role=cps_bia_etl_role',
                'cloud_snowflake_db_engine_str': 'snowflake://cps_bia_etl_svc:{pw}@ciscodev.us-east-1.privatelink/CPS_DB/{schema}?warehouse={wh}&role=cps_bia_etl_role'
            }


    }


    return sf_key_info


def get_sf_pw(conn_name, wh, schema):
    cn = sf_key()[conn_name.lower()]
    # client = hvac.Client(
    #     url=cn['url'],
    #     namespace=cn['namespace'],
    #     token=cn['token']
    # )
    # jsonval = client.read(cn['secret'])
    # value = json.dumps(jsonval["data"])
    # pw = urlquote(json.loads(value)['passwd'])
    # print(pw)
    if socket.gethostname() in ('cps-node-009' , 'ALANZEN-P865P', 'EJUROTIC-M-45YS'):
        con_string = cn['snowflake_db_engine_str'].format( schema=schema, wh=wh)
    else:
        con_string = cn['snowflake_db_engine_str'].format( schema=schema, wh=wh) # use if you always want to use local con, for example ts in a docker image on the server
        #con_string = cn['cloud_snowflake_db_engine_str'].format( schema=schema, wh=wh) # use for all other use cases




    return con_string
