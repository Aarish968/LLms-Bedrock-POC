admin_pass = "KKq85ARNgkELvsa"
dev_admin_pass = "KKq85ARNgkELvsa"
ACCESS_KEY = "AKIA4GA4KVC7JYPGW64X"
SECRET_KEY = "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"
