#!/usr/bin/env python3
"""
Simple test to verify that the LineageAnalysisRequest model accepts empty requests
"""

import sys
import os
import json

# Add the API to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

def test_model_validation():
    """Test that the model accepts requests without database_filter and schema_filter"""
    try:
        # Import the model
        from api.v1.models.lineage import LineageAnalysisRequest
        
        print("=== Testing Model Validation ===")
        
        # Test 1: Empty request
        print("\n1. Testing empty request...")
        try:
            empty_request = LineageAnalysisRequest()
            print("✓ Empty request accepted")
            print(f"  database_filter: {empty_request.database_filter}")
            print(f"  schema_filter: {empty_request.schema_filter}")
        except Exception as e:
            print(f"✗ Empty request failed: {e}")
            return False
        
        # Test 2: Request with only view_names
        print("\n2. Testing request with only view_names...")
        try:
            view_request = LineageAnalysisRequest(view_names=["TEST_VIEW"])
            print("✓ Request with view_names accepted")
            print(f"  database_filter: {view_request.database_filter}")
            print(f"  schema_filter: {view_request.schema_filter}")
        except Exception as e:
            print(f"✗ Request with view_names failed: {e}")
            return False
        
        # Test 3: JSON parsing (simulating API request)
        print("\n3. Testing JSON parsing...")
        try:
            json_data = {}
            request_from_json = LineageAnalysisRequest(**json_data)
            print("✓ JSON parsing successful")
            print(f"  database_filter: {request_from_json.database_filter}")
            print(f"  schema_filter: {request_from_json.schema_filter}")
        except Exception as e:
            print(f"✗ JSON parsing failed: {e}")
            return False
        
        # Test 4: JSON with view_names
        print("\n4. Testing JSON with view_names...")
        try:
            json_data = {"view_names": ["VIEW1", "VIEW2"]}
            request_from_json = LineageAnalysisRequest(**json_data)
            print("✓ JSON with view_names successful")
            print(f"  view_names: {request_from_json.view_names}")
            print(f"  database_filter: {request_from_json.database_filter}")
            print(f"  schema_filter: {request_from_json.schema_filter}")
        except Exception as e:
            print(f"✗ JSON with view_names failed: {e}")
            return False
        
        return True
        
    except ImportError as e:
        print(f"✗ Import error: {e}")
        print("Make sure you're running this from the column-lineage-api directory")
        return False
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        return False

if __name__ == "__main__":
    success = test_model_validation()
    
    if success:
        print("\n✓ All model validation tests passed!")
        print("The LineageAnalysisRequest model now accepts requests without database_filter and schema_filter.")
        print("\nIf you're still getting 'Field required' errors:")
        print("1. Restart your API server to reload the code")
        print("2. Check if you're hitting a different endpoint")
        print("3. Verify the request is going to the correct URL")
    else:
        print("\n✗ Model validation tests failed!")
        print("The model still requires database_filter and schema_filter fields.")
        sys.exit(1)