#!/usr/bin/env python3
"""
Debug script to test background task execution and job completion
"""

import requests
import time
import json

def test_background_task():
    """Test the background task execution and job status updates"""
    
    base_url = "http://localhost:8000"
    
    print("=== Background Task Debug Test ===\n")
    
    # Test 1: Start an async analysis
    print("1. Starting async analysis...")
    
    analysis_request = {
        "database_filter": "CPS_DB",
        "schema_filter": "CPS_DSCI_BR", 
        "view_names": ["STUDENT_ENROLLMENT_SUMMARY", "COURSE_COMPLETION_RATES"],  # Just 2 views for testing
        "async_processing": True,  # This is key - async processing
        "include_system_views": False
    }
    
    try:
        response = requests.post(
            f"{base_url}/api/v1/lineage/analyze",
            json=analysis_request,
            timeout=30  # Longer timeout for the initial request
        )
        
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            job_id = data.get('job_id')
            print(f"✅ Analysis started successfully")
            print(f"Job ID: {job_id}")
            print(f"Status: {data.get('status')}")
            print(f"Message: {data.get('message')}")
            
            # Test 2: Monitor job status
            print(f"\n2. Monitoring job status...")
            
            max_wait_time = 300  # 5 minutes max
            check_interval = 5   # Check every 5 seconds
            
            for i in range(0, max_wait_time, check_interval):
                try:
                    status_response = requests.get(
                        f"{base_url}/api/v1/lineage/status/{job_id}",
                        timeout=10
                    )
                    
                    if status_response.status_code == 200:
                        status_data = status_response.json()
                        current_status = status_data.get('status')
                        processed_views = status_data.get('processed_views', 0)
                        total_views = status_data.get('total_views', 0)
                        
                        print(f"  [{i:3d}s] Status: {current_status}, Progress: {processed_views}/{total_views}")
                        
                        if current_status in ['COMPLETED', 'FAILED']:
                            print(f"\n✅ Job finished with status: {current_status}")
                            
                            if current_status == 'COMPLETED':
                                # Test 3: Get results
                                print(f"\n3. Getting results...")
                                results_response = requests.get(
                                    f"{base_url}/api/v1/lineage/results/{job_id}",
                                    timeout=30
                                )
                                
                                if results_response.status_code == 200:
                                    results_data = results_response.json()
                                    print(f"✅ Results retrieved successfully")
                                    print(f"Total results: {results_data.get('total_results', 0)}")
                                    print(f"Results count: {len(results_data.get('results', []))}")
                                    
                                    # Show first few results
                                    results = results_data.get('results', [])
                                    if results:
                                        print(f"\nFirst 3 results:")
                                        for i, result in enumerate(results[:3]):
                                            print(f"  {i+1}. {result.get('view_name')}.{result.get('view_column')} -> {result.get('source_table')}.{result.get('source_column')}")
                                else:
                                    print(f"❌ Failed to get results: {results_response.status_code}")
                                    print(f"Response: {results_response.text}")
                            else:
                                # Job failed
                                error_message = status_data.get('error_message', 'Unknown error')
                                print(f"❌ Job failed: {error_message}")
                            
                            break
                    else:
                        print(f"  [{i:3d}s] ❌ Status check failed: {status_response.status_code}")
                        
                except requests.exceptions.RequestException as e:
                    print(f"  [{i:3d}s] ❌ Request error: {e}")
                
                time.sleep(check_interval)
            else:
                print(f"\n⏰ Timeout reached ({max_wait_time}s) - job may still be running")
                
        else:
            print(f"❌ Failed to start analysis: {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")

if __name__ == "__main__":
    test_background_task()