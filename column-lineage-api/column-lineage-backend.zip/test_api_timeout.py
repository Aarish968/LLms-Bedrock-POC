#!/usr/bin/env python3
"""
Test script to diagnose API timeout issues
"""

import requests
import time
import json

def test_api_endpoints():
    """Test various API endpoints to identify timeout issues"""
    
    base_url = "http://localhost:8000"  # Adjust if your API runs on different port
    
    endpoints = [
        {
            "name": "Health Check",
            "url": f"{base_url}/api/v1/lineage/public/health",
            "timeout": 5
        },
        {
            "name": "Base View (Mock Mode)",
            "url": f"{base_url}/api/v1/lineage/public/base-view?mock=true",
            "timeout": 10
        },
        {
            "name": "Base View (Real Data)",
            "url": f"{base_url}/api/v1/lineage/public/base-view",
            "timeout": 30
        }
    ]
    
    print("=== API Timeout Diagnosis ===\n")
    
    for endpoint in endpoints:
        print(f"Testing: {endpoint['name']}")
        print(f"URL: {endpoint['url']}")
        
        start_time = time.time()
        
        try:
            response = requests.get(
                endpoint['url'], 
                timeout=endpoint['timeout']
            )
            
            end_time = time.time()
            duration = end_time - start_time
            
            print(f"Status: {response.status_code}")
            print(f"Duration: {duration:.2f} seconds")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    if isinstance(data, dict):
                        if 'total_records' in data:
                            print(f"Total Records: {data['total_records']}")
                            print(f"Records Returned: {len(data.get('records', []))}")
                        else:
                            print(f"Response Keys: {list(data.keys())}")
                    print("✅ SUCCESS")
                except json.JSONDecodeError:
                    print("⚠️  Response is not valid JSON")
            else:
                print(f"❌ FAILED - Status: {response.status_code}")
                print(f"Response: {response.text[:200]}...")
                
        except requests.exceptions.Timeout:
            end_time = time.time()
            duration = end_time - start_time
            print(f"❌ TIMEOUT after {duration:.2f} seconds")
            
        except requests.exceptions.ConnectionError:
            print("❌ CONNECTION ERROR - Is the API server running?")
            
        except Exception as e:
            print(f"❌ ERROR: {e}")
        
        print("-" * 50)
        print()

if __name__ == "__main__":
    test_api_endpoints()