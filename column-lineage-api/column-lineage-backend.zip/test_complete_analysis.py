#!/usr/bin/env python3
"""Test complete analysis flow with a PUBLIC schema view."""

import sys
import os
import json
import asyncio

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api.v1.services.lineage_service import LineageService
from api.v1.models.lineage import LineageAnalysisRequest

async def test_complete_analysis():
    """Test complete analysis flow."""
    print("🔍 Testing Complete Analysis Flow")
    print("=" * 50)
    
    try:
        lineage_service = LineageService()
        
        # Create analysis request for PUBLIC schema views
        request = LineageAnalysisRequest(
            view_names=["ALL_IB"],  # Test with one specific view
            database_filter="SNOWFLAKE_LEARNING_DB",
            schema_filter="PUBLIC",
            async_processing=False,  # Synchronous for testing
            include_system_views=False,
            max_views=1
        )
        
        print(f"\n1. Starting analysis for view: {request.view_names[0]}")
        print(f"   Database: {request.database_filter}")
        print(f"   Schema: {request.schema_filter}")
        
        # Create a mock job ID
        from uuid import uuid4
        job_id = uuid4()
        user_id = "test-user"
        
        print(f"   Job ID: {job_id}")
        
        # Run the analysis
        results = await lineage_service.process_lineage_analysis(
            job_id=job_id,
            request=request,
            user_id=user_id
        )
        
        print(f"\n2. Analysis completed!")
        print(f"   Results count: {len(results)}")
        
        if results:
            print(f"\n3. Sample results:")
            for i, result in enumerate(results[:5]):  # Show first 5 results
                print(f"   Result {i+1}:")
                print(f"     View: {result.view_name}")
                print(f"     Column: {result.view_column}")
                print(f"     Type: {result.column_type}")
                print(f"     Source: {result.source_table}.{result.source_column}")
                print(f"     Confidence: {result.confidence_score}")
                if result.metadata:
                    print(f"     Metadata: {json.dumps(result.metadata, indent=6)}")
                print()
        else:
            print("   No results found")
        
        # Check if CSV file was created
        from pathlib import Path
        results_dir = Path("analysis_results")
        if results_dir.exists():
            csv_files = list(results_dir.glob("lineage_analysis_*.csv"))
            if csv_files:
                print(f"\n4. Auto-saved CSV files:")
                for csv_file in csv_files:
                    print(f"   - {csv_file.name} ({csv_file.stat().st_size} bytes)")
            else:
                print(f"\n4. No CSV files found in {results_dir}")
        else:
            print(f"\n4. Results directory {results_dir} does not exist")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_complete_analysis())