#!/usr/bin/env python3
"""Test database query functionality."""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api.dependencies.database import DatabaseManager

def test_database_query():
    """Test querying the database results table."""
    print("🔍 Testing Database Query Functionality")
    print("=" * 50)
    
    try:
        db_manager = DatabaseManager()
        
        database_name = "SNOWFLAKE_LEARNING_DB"
        schema_name = "PUBLIC"
        table_name = "COLUMN_LINEAGE_RESULTS"
        full_table_name = f"{database_name}.{schema_name}.{table_name}"
        
        print(f"\n1. Querying table: {full_table_name}")
        
        # Count total records
        count_query = f"SELECT COUNT(*) as total FROM {full_table_name}"
        count_result = db_manager.execute_query(count_query)
        total_records = count_result[0][0] if count_result else 0
        
        print(f"✅ Total records in table: {total_records}")
        
        if total_records > 0:
            # Get sample records
            sample_query = f"""
            SELECT 
                JOB_ID,
                VIEW_NAME,
                VIEW_COLUMN,
                COLUMN_TYPE,
                SOURCE_TABLE,
                SOURCE_COLUMN,
                EXPRESSION_TYPE,
                ANALYSIS_TIMESTAMP,
                CREATED_AT
            FROM {full_table_name}
            ORDER BY CREATED_AT DESC, VIEW_COLUMN
            LIMIT 10
            """
            
            results = db_manager.execute_query(sample_query)
            
            print(f"\n2. Sample records (showing first 10):")
            for i, row in enumerate(results):
                print(f"   Record {i+1}:")
                print(f"     Job ID: {row[0]}")
                print(f"     View: {row[1]}")
                print(f"     Column: {row[2]}")
                print(f"     Type: {row[3]}")
                print(f"     Source: {row[4]}.{row[5]}")
                print(f"     Expression Type: {row[6] or 'N/A'}")
                print(f"     Analysis Time: {row[7]}")
                print(f"     Created At: {row[8]}")
                print()
            
            # Test filtering by job ID
            print(f"\n3. Testing job ID filtering...")
            job_ids_query = f"SELECT DISTINCT JOB_ID FROM {full_table_name} ORDER BY JOB_ID LIMIT 3"
            job_ids_result = db_manager.execute_query(job_ids_query)
            
            if job_ids_result:
                test_job_id = job_ids_result[0][0]
                print(f"   Testing with Job ID: {test_job_id}")
                
                filtered_query = f"""
                SELECT COUNT(*) as count
                FROM {full_table_name}
                WHERE JOB_ID = '{test_job_id}'
                """
                
                filtered_result = db_manager.execute_query(filtered_query)
                filtered_count = filtered_result[0][0] if filtered_result else 0
                
                print(f"   Records for this job: {filtered_count}")
        
        print(f"\n✅ Database query test completed!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_database_query()