#!/usr/bin/env python3
"""
Test script to track database_filter and schema_filter values
"""

import os
import sys
import json
import requests
from datetime import datetime

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_config_endpoint():
    """Test the config endpoint to see current settings"""
    print("=== Configuration Tracking Test ===\n")
    
    base_url = "http://localhost:8000"  # Adjust if needed
    
    try:
        # Test config endpoint
        response = requests.get(f"{base_url}/api/v1/lineage/public/config", timeout=10)
        
        if response.status_code == 200:
            config = response.json()
            print("Current Configuration:")
            print(json.dumps(config, indent=2))
        else:
            print(f"Failed to get config: {response.status_code}")
            print(response.text)
            
    except Exception as e:
        print(f"Error testing config endpoint: {e}")

def test_lineage_request_tracking():
    """Test lineage analysis request with different database/schema values"""
    print("\n=== Lineage Request Tracking Test ===\n")
    
    base_url = "http://localhost:8000"
    
    # Test different scenarios
    test_cases = [
        {
            "name": "Default Values (from environment)",
            "payload": {
                "view_names": ["TEST_VIEW"],
                "async_processing": False
            }
        },
        {
            "name": "Custom Database/Schema",
            "payload": {
                "view_names": ["TEST_VIEW"],
                "database_filter": "CUSTOM_DB",
                "schema_filter": "CUSTOM_SCHEMA",
                "async_processing": False
            }
        },
        {
            "name": "Empty Database/Schema",
            "payload": {
                "view_names": ["TEST_VIEW"],
                "database_filter": "",
                "schema_filter": "",
                "async_processing": False
            }
        }
    ]
    
    for test_case in test_cases:
        print(f"Testing: {test_case['name']}")
        print(f"Payload: {json.dumps(test_case['payload'], indent=2)}")
        
        try:
            # Note: This endpoint requires authentication, so it might fail
            # But we can see the request structure
            response = requests.post(
                f"{base_url}/api/v1/lineage/analyze",
                json=test_case['payload'],
                timeout=10
            )
            
            print(f"Status: {response.status_code}")
            if response.status_code != 200:
                print(f"Response: {response.text[:200]}...")
            else:
                result = response.json()
                print(f"Job ID: {result.get('job_id')}")
                
        except Exception as e:
            print(f"Error: {e}")
        
        print("-" * 50)

def show_environment_values():
    """Show current environment variable values"""
    print("\n=== Environment Variables ===\n")
    
    env_vars = [
        "SNOWFLAKE_DATABASE",
        "SNOWFLAKE_SCHEMA", 
        "AUTO_SAVE_RESULTS",
        "AUTO_SAVE_TO_DATABASE",
        "AUTO_SAVE_DATABASE_OVERRIDE",
        "AUTO_SAVE_SCHEMA_OVERRIDE",
        "BASE_VIEW_TABLE"
    ]
    
    for var in env_vars:
        value = os.getenv(var, "Not Set")
        print(f"{var}: {value}")

def show_model_defaults():
    """Show the default values from the Pydantic model"""
    print("\n=== Model Defaults ===\n")
    
    try:
        from api.v1.models.lineage import LineageAnalysisRequest, DEFAULT_DATABASE, DEFAULT_SCHEMA
        
        print(f"DEFAULT_DATABASE: {DEFAULT_DATABASE}")
        print(f"DEFAULT_SCHEMA: {DEFAULT_SCHEMA}")
        
        # Create a sample request to see defaults
        sample_request = LineageAnalysisRequest()
        print(f"Sample request database_filter: {sample_request.database_filter}")
        print(f"Sample request schema_filter: {sample_request.schema_filter}")
        
    except Exception as e:
        print(f"Error loading model: {e}")

if __name__ == "__main__":
    show_environment_values()
    show_model_defaults()
    test_config_endpoint()
    test_lineage_request_tracking()